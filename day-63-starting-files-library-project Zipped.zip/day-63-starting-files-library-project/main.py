from flask import Flask, render_template, request, redirect, url_for
import sqlite3

app = Flask(__name__)

def get_db_connection():
    conn = sqlite3.connect("boobs.db")
    conn.row_factory = sqlite3.Row  
    return conn
db = get_db_connection()
cursor = db.cursor()
cursor.execute("""
    CREATE TABLE IF NOT EXISTS books (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title VARCHAR(250) NOT NULL UNIQUE,
        author VARCHAR(250) NOT NULL,
        rating FLOAT NOT NULL
    )
""")
db.commit()
db.close()

@app.route("/", methods=["GET"])
def home():
    db = get_db_connection()
    cursor = db.cursor()
    cursor.execute("SELECT * FROM books")
    
    books = [dict(row) for row in cursor.fetchall()]  
    
    db.close()
    return render_template("index.html", books=books)


@app.route("/add", methods=["GET", "POST"])
def add():
    if request.method == "POST":
        book_name = request.form["book_name"]
        book_author = request.form["book_author"]
        rating = request.form["rating"]

        db = get_db_connection()
        cursor = db.cursor()
        cursor.execute("INSERT INTO books (title, author, rating) VALUES (?, ?, ?)", 
                       (book_name, book_author, rating))
        db.commit()
        db.close()
        
        return redirect(url_for("home"))
    return render_template("add.html")


@app.route("/edit/<int:book_id>", methods=["GET", "POST"])
def edit(book_id):
    db = get_db_connection()
    cursor = db.cursor()

    if request.method == "POST":
        new_title = request.form["book_name"]
        new_author = request.form["book_author"]
        new_rating = request.form["rating"]

        cursor.execute("UPDATE books SET title=?, author=?, rating=? WHERE id=?", 
                       (new_title, new_author, new_rating, book_id))
        db.commit()
        db.close()
        
        return redirect(url_for("home"))

    cursor.execute("SELECT * FROM books WHERE id=?", (book_id,))
    book = cursor.fetchone()
    db.close()

    if book:
        return render_template("edit.html", book=dict(book))
    return redirect(url_for("home"))


@app.route("/delete/<int:book_id>")
def delete(book_id):
    db = get_db_connection()
    cursor = db.cursor()
    cursor.execute("DELETE FROM books WHERE id=?", (book_id,))
    db.commit()
    db.close()

    return redirect(url_for("home"))

if __name__ == "__main__":
    app.run(debug=True)
