from flask import Flask, render_template
import requests

app = Flask(__name__)

@app.route('/')
def home():
    return render_template("index.html")

@app.route('/Cool-Kids')
def get_cool_kids():
    resp = requests.get("https://api.npoint.io/da028716a26ec59aab36")
    resp.raise_for_status()
    blog = resp.json()
    return render_template ('cool-kids.html', blogs = blog)

@app.route('/Men')
def get_men():
    resp = requests.get("https://api.npoint.io/6dbe81a97dbb707fb496")
    resp.raise_for_status()
    blog = resp.json()
    return render_template ('men.html', blogs = blog)

if __name__ == "__main__":
    app.run(debug=True)
