from flask import Flask, render_template, request
import smtplib

from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/About')
def get_about():
    return render_template('about.html')

@app.route('/Services')
def get_serv():
    return render_template('serv.html')

@app.route('/Contact', methods=["GET", "POST"])  
def get_contact():
    if request.method == "POST":
        email = request.form.get('validationTooltip01')
        mess = request.form.get('validationTooltip03')

        if email and mess:
            my_mail = "silvervoid3.14@gmail.com"
            pwd = "pmcu eyxv ezgb dcbq"
            print(f"Email: {email}, Message: {mess}")
            with smtplib.SMTP("smtp.gmail.com", 587) as con:
                con.starttls()
                con.login(user = my_mail, password = pwd)
                con.sendmail(from_addr= my_mail, to_addrs= email, msg = mess)   
            return render_template('submitted.html', e=email, me=mess)       
    return render_template('contact.html')


@app.route('/terms')
def get_terms():
    return render_template('terms.html')

@app.route('/Privecy-Policy')
def get_pp():
    return render_template('pp.html')

if __name__ == "__main__":
    app.run(debug = True)