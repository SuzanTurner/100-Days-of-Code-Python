import random
n = random.randint(0,10)

from flask import Flask
app = Flask(__name__)

@app.route('/')
def guess():
    return """<h2 style = 'text-align:center'> This is the Home Page </h2> \
            <div style="display: flex; justify-content: center; align-items: center; height: 80vh;">
            <img src="/static/housee.png" alt="House Image" style="max-width: 100%; height: auto;">
            </div> \
            <h5 style = 'text-align:center'> You have to guess a number between 1-10 </h5> \
            <h3 style = 'text-align:center'> Type that in the url </h3>  """


@app.route('/<int:num>')
def number(num):
    if num == n:
        return """ <h2 style = 'text-align:center'> You guessed Correctly!! </h2>
        <img src="/static/yes.gif">
        """
    else:
        return """ <h2 style = 'text-align:center'> You missed it lol </h2>
        <img src="/static/no.gif">
        """


if __name__ == "__main__":
    app.run(debug = True)